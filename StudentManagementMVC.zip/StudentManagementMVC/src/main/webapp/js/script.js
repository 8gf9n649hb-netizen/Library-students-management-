function validateForm() {
    const age = Number(document.getElementById("age").value);

    if (age < 1 || age > 100) {
        alert("Please enter an age between 1 and 100.");
        return false;
    }

    return true;
}

function filterStudents() {
    const query = document.getElementById("search").value.toLowerCase();
    const rows = document.querySelectorAll("#studentBody tr");

    rows.forEach(row => {
        row.style.display = row.innerText.toLowerCase().includes(query) ? "" : "none";
    });
}
