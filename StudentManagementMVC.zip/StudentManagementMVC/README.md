# Student Management System — Java MVC + JDBC + MySQL

A beginner-friendly Student Management web application using:
- Java Servlets (Controller)
- Java classes (Model/DAO)
- JDBC
- MySQL
- HTML/CSS/JavaScript (Frontend)
- Apache Tomcat

## Project structure

StudentManagementMVC/
├── database/
│   └── student_management.sql
├── src/main/java/com/studentmanagement/
│   ├── controller/
│   │   └── StudentServlet.java
│   ├── dao/
│   │   └── StudentDAO.java
│   ├── model/
│   │   └── Student.java
│   └── util/
│       └── DBConnection.java
├── src/main/webapp/
│   ├── index.html
│   ├── add-student.html
│   ├── css/style.css
│   └── js/script.js
├── pom.xml
└── README.md

## Requirements

1. JDK 17+
2. MySQL 8+
3. Apache Tomcat 10.1+
4. Maven 3.9+

## Database setup

Run database/student_management.sql in MySQL.

Default connection:
- Database: student_management
- Username: root
- Password: root

If your MySQL password is different, edit:
src/main/java/com/studentmanagement/util/DBConnection.java

## Run

From the project folder:

mvn clean package

Copy:
target/StudentManagementMVC.war

to your Tomcat `webapps` folder.

Start Tomcat and open:
http://localhost:8080/StudentManagementMVC/

## MVC flow

Browser → StudentServlet (Controller) → StudentDAO/Student (Model) → JDBC → MySQL

## CRUD endpoints

GET  /students?action=list
POST /students?action=add
POST /students?action=update
POST /students?action=delete

This is a learning project. For production use, add authentication, validation, CSRF protection, connection pooling, environment-based secrets, and HTTPS.
